package com.retrohub.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.retrohub.data.AppEntry
import com.retrohub.data.AppLauncher
import com.retrohub.data.ArtScraper
import com.retrohub.data.LibraryStore
import com.retrohub.data.Rom
import com.retrohub.data.RomScanner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("retrohub", 0)

    private val _roms = MutableStateFlow<List<Rom>>(emptyList())
    val roms: StateFlow<List<Rom>> = _roms

    private val _apps = MutableStateFlow<List<AppEntry>>(emptyList())
    val apps: StateFlow<List<AppEntry>> = _apps

    private val _status = MutableStateFlow<String?>(null)
    val status: StateFlow<String?> = _status

    /** Bumped whenever new art lands on disk so the grid re-checks files. */
    private val _artVersion = MutableStateFlow(0)
    val artVersion: StateFlow<Int> = _artVersion

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy

    val hasRomFolder: Boolean get() = prefs.getString(KEY_TREE, null) != null

    init {
        viewModelScope.launch(Dispatchers.IO) {
            _roms.value = LibraryStore.load(app)
        }
        refreshApps()
    }

    fun refreshApps() {
        viewModelScope.launch(Dispatchers.Default) {
            _apps.value = runCatching { AppLauncher.list(getApplication()) }.getOrDefault(emptyList())
        }
    }

    fun setRomFolder(uri: Uri) {
        prefs.edit().putString(KEY_TREE, uri.toString()).apply()
        rescan()
    }

    fun rescan() {
        val tree = prefs.getString(KEY_TREE, null)?.let(Uri::parse) ?: return
        if (_busy.value) return
        viewModelScope.launch {
            _busy.value = true
            _status.value = "Scanning for games…"
            val found = withContext(Dispatchers.IO) {
                runCatching { RomScanner.scan(getApplication(), tree) }.getOrDefault(emptyList())
            }
            withContext(Dispatchers.IO) { LibraryStore.save(getApplication(), found) }
            _roms.value = found
            _status.value = "Found ${found.size} games"
            _busy.value = false
            scrapeAll()
        }
    }

    fun scrapeAll() {
        if (_busy.value && _status.value?.startsWith("Scanning") != true) return
        viewModelScope.launch {
            _busy.value = true
            val ctx = getApplication<Application>()
            val todo = _roms.value.filter { !ArtScraper.artFile(ctx, it).exists() }
            var done = 0
            var got = 0
            for (chunk in todo.chunked(4)) {
                val results = withContext(Dispatchers.IO) {
                    chunk.map { rom -> async { ArtScraper.fetch(ctx, rom) } }.awaitAll()
                }
                done += chunk.size
                got += results.count { it }
                _status.value = "Box art: $done / ${todo.size}"
                if (results.any { it }) _artVersion.value++
            }
            _status.value = if (todo.isEmpty()) "Box art is up to date" else "Box art: found $got of ${todo.size}"
            _busy.value = false
        }
    }

    private companion object {
        const val KEY_TREE = "romTree"
    }
}
