package com.retrohub.data

import android.content.Context
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * Cores are downloaded on first use from the libretro nightly Android buildbot and stored
 * in app-private storage. Offline? Drop <core>_libretro_android.so into the app's external
 * "cores" folder (Android/data/com.retrohub/files/cores) and it will be imported.
 */
object CoreManager {
    private const val BASE = "https://buildbot.libretro.com/nightly/android/latest"
    private val SUPPORTED_ABIS = setOf("arm64-v8a", "armeabi-v7a", "x86_64", "x86")

    private fun abi() = Build.SUPPORTED_ABIS.firstOrNull { it in SUPPORTED_ABIS } ?: "arm64-v8a"
    private fun fileName(core: String) = "${core}_libretro_android.so"
    fun coreFile(ctx: Context, core: String) = File(ctx.filesDir, "cores/${fileName(core)}")
    fun isInstalled(ctx: Context, core: String) = coreFile(ctx, core).exists()

    suspend fun ensure(ctx: Context, core: String, onStatus: (String) -> Unit): File =
        withContext(Dispatchers.IO) {
            val target = coreFile(ctx, core)
            if (target.exists()) return@withContext target
            target.parentFile?.mkdirs()

            // Offline import. Executable code must live in internal storage, so copy it over.
            val sideloaded = File(ctx.getExternalFilesDir("cores"), fileName(core))
            if (sideloaded.exists()) {
                sideloaded.copyTo(target, overwrite = true)
                target.setReadOnly() // Android 14+ refuses to load writable dynamic code
                return@withContext target
            }

            onStatus("Downloading $core core…")
            val url = URL("$BASE/${abi()}/${fileName(core)}.zip")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000
                readTimeout = 60_000
            }
            try {
                if (conn.responseCode != 200) {
                    error("Core '$core' isn't available for ${abi()} (HTTP ${conn.responseCode}).")
                }
                ZipInputStream(conn.inputStream).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        if (entry.name.endsWith(".so")) {
                            val tmp = File(target.path + ".tmp")
                            tmp.outputStream().use { zip.copyTo(it) }
                            tmp.setReadOnly()
                            if (!tmp.renameTo(target)) error("Couldn't install core $core")
                            return@withContext target
                        }
                        entry = zip.nextEntry
                    }
                }
                error("Downloaded archive for '$core' contained no .so file.")
            } finally {
                conn.disconnect()
            }
        }
}
