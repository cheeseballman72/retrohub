package com.retrohub.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.retrohub.data.AppEntry
import com.retrohub.data.ArtScraper
import com.retrohub.data.CoreManager
import com.retrohub.data.GameSystem
import com.retrohub.data.Kind
import com.retrohub.data.Rom
import com.retrohub.data.Systems

private enum class Tab(val label: String) { GAMES("Games"), APPS("Apps"), SETTINGS("Settings") }

@Composable
fun RetroHubTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(), content = content)
}

@Composable
fun RetroHubApp(
    vm: MainViewModel,
    onPickFolder: () -> Unit,
    onLaunchRom: (Rom) -> Unit,
    onLaunchApp: (AppEntry) -> Unit,
) {
    var tab by remember { mutableStateOf(Tab.GAMES) }
    val roms by vm.roms.collectAsStateWithLifecycle()
    val apps by vm.apps.collectAsStateWithLifecycle()
    val status by vm.status.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val artVersion by vm.artVersion.collectAsStateWithLifecycle()

    Scaffold(
        bottomBar = {
            NavigationBar {
                Tab.values().forEach { t ->
                    NavigationBarItem(
                        selected = tab == t,
                        onClick = { tab = t },
                        icon = { Text(when (t) { Tab.GAMES -> "🎮"; Tab.APPS -> "📱"; Tab.SETTINGS -> "⚙" }) },
                        label = { Text(t.label) },
                    )
                }
            }
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding).statusBarsPadding()) {
            when (tab) {
                Tab.GAMES -> GamesTab(roms, artVersion, vm.hasRomFolder, onPickFolder, onLaunchRom)
                Tab.APPS -> AppsTab(apps, onLaunchApp)
                Tab.SETTINGS -> SettingsTab(status, busy, roms.size, onPickFolder, vm::rescan, vm::scrapeAll)
            }
        }
    }
}

// ---------------------------------------------------------------- Games

@Composable
private fun GamesTab(
    roms: List<Rom>,
    artVersion: Int,
    hasFolder: Boolean,
    onPickFolder: () -> Unit,
    onLaunch: (Rom) -> Unit,
) {
    var selected by remember { mutableStateOf<GameSystem?>(null) }
    BackHandler(enabled = selected != null) { selected = null }

    if (roms.isEmpty()) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("No games yet", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(8.dp))
            Text(
                if (hasFolder) "Nothing recognised in your ROM folder. Use one sub-folder per system (e.g. SNES, PSX) for disc formats."
                else "Pick the folder that holds your ROMs.",
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = onPickFolder) { Text("Choose ROM folder") }
        }
        return
    }

    val system = selected
    if (system == null) {
        SystemPicker(roms) { selected = it }
    } else {
        GameGrid(system, roms.filter { it.systemId == system.id }, artVersion, onLaunch) { selected = null }
    }
}

@Composable
private fun SystemPicker(roms: List<Rom>, onSelect: (GameSystem) -> Unit) {
    val counts = roms.groupingBy { it.systemId }.eachCount()
    val present = Systems.all.filter { counts.containsKey(it.id) }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(150.dp),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        for (kind in Kind.values()) {
            val group = present.filter { it.kind == kind }.sortedBy { it.gen }
            if (group.isEmpty()) continue
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    if (kind == Kind.CONSOLE) "Consoles" else "Handhelds",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
            items(group, key = { it.id }) { sys ->
                Card(Modifier.fillMaxWidth().clickable { onSelect(sys) }) {
                    Column(Modifier.padding(16.dp)) {
                        Text(sys.name, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text("${counts[sys.id]} games", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun GameGrid(
    system: GameSystem,
    games: List<Rom>,
    artVersion: Int,
    onLaunch: (Rom) -> Unit,
    onBack: () -> Unit,
) {
    val ctx = LocalContext.current
    LazyVerticalGrid(
        columns = GridCells.Adaptive(120.dp),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = onBack) { Text("‹ Back") }
                Spacer(Modifier.size(12.dp))
                Text(system.name, style = MaterialTheme.typography.titleLarge)
            }
        }
        items(games, key = { it.uri }) { rom ->
            // artVersion is a key so the file check re-runs after the scraper writes new art.
            val art = remember(rom.uri, artVersion) { ArtScraper.artFile(ctx, rom).takeIf { it.exists() } }
            Column(Modifier.clickable { onLaunch(rom) }) {
                Box(
                    Modifier.fillMaxWidth().aspectRatio(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center,
                ) {
                    if (art != null) {
                        AsyncImage(model = art, contentDescription = rom.title, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                    } else {
                        Text(rom.title.take(1).uppercase(), style = MaterialTheme.typography.headlineLarge)
                    }
                }
                Text(rom.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

// ---------------------------------------------------------------- Apps

@Composable
private fun AppsTab(apps: List<AppEntry>, onLaunch: (AppEntry) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(84.dp),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        items(apps, key = { it.packageName }) { app ->
            Column(
                Modifier.clickable { onLaunch(app) },
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Image(app.icon, contentDescription = app.label, modifier = Modifier.size(56.dp))
                Text(app.label, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

// ---------------------------------------------------------------- Settings

@Composable
private fun SettingsTab(
    status: String?,
    busy: Boolean,
    gameCount: Int,
    onPickFolder: () -> Unit,
    onRescan: () -> Unit,
    onScrape: () -> Unit,
) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Library", style = MaterialTheme.typography.titleLarge)
        Text("$gameCount games")
        Button(onClick = onPickFolder) { Text("Choose ROM folder") }
        OutlinedButton(onClick = onRescan, enabled = !busy) { Text("Rescan library") }
        OutlinedButton(onClick = onScrape, enabled = !busy) { Text("Download missing box art") }
        if (status != null) Text(status, style = MaterialTheme.typography.bodyMedium)

        Spacer(Modifier.height(8.dp))
        Text("BIOS files", style = MaterialTheme.typography.titleMedium)
        Text(
            "Put BIOS files (PlayStation, Saturn, Sega CD, Dreamcast, etc.) in:\n" +
                (ctx.getExternalFilesDir("system")?.absolutePath ?: "(unavailable)"),
            style = MaterialTheme.typography.bodySmall,
        )
        Spacer(Modifier.height(8.dp))
        Text("Cores", style = MaterialTheme.typography.titleMedium)
        val installed = Systems.all.map { it.core }.distinct().count { CoreManager.isInstalled(ctx, it) }
        Text("$installed cores downloaded. Cores download automatically the first time you launch a system.", style = MaterialTheme.typography.bodySmall)
    }
}
