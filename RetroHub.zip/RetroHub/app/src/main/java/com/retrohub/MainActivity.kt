package com.retrohub

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.retrohub.data.AppEntry
import com.retrohub.data.AppLauncher
import com.retrohub.data.Rom
import com.retrohub.emulation.GameActivity
import com.retrohub.ui.MainViewModel
import com.retrohub.ui.RetroHubApp
import com.retrohub.ui.RetroHubTheme

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            vm.setRomFolder(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RetroHubTheme {
                RetroHubApp(
                    vm = vm,
                    onPickFolder = { pickFolder.launch(null) },
                    onLaunchRom = ::launchRom,
                    onLaunchApp = ::launchApp,
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refreshApps() // pick up installs/uninstalls while we were away
    }

    private fun launchRom(rom: Rom) {
        startActivity(
            Intent(this, GameActivity::class.java)
                .putExtra(GameActivity.EXTRA_URI, rom.uri)
                .putExtra(GameActivity.EXTRA_SYSTEM, rom.systemId)
                .putExtra(GameActivity.EXTRA_TITLE, rom.title)
        )
    }

    private fun launchApp(app: AppEntry) {
        if (!AppLauncher.launch(this, app.packageName)) {
            Toast.makeText(this, "Can't open ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }
}
