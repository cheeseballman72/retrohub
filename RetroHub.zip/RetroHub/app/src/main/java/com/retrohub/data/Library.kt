package com.retrohub.data

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

@Serializable
data class Rom(
    val uri: String,
    val title: String,
    val fileName: String,
    val systemId: String,
)

object RomScanner {
    private val DISC_DATA = setOf("bin", "img")

    /** Walks a SAF tree and returns every recognised game. Run off the main thread. */
    fun scan(ctx: Context, tree: Uri): List<Rom> {
        val root = DocumentFile.fromTreeUri(ctx, tree) ?: return emptyList()
        val out = mutableListOf<Rom>()
        walk(root, listOfNotNull(root.name), out)
        return out.sortedBy { it.title.lowercase() }
    }

    private fun walk(dir: DocumentFile, ancestors: List<String>, out: MutableList<Rom>) {
        val children = dir.listFiles()
        val names = children.mapNotNull { it.name }
        val cueBases = names.filter { it.endsWith(".cue", true) }
            .map { it.substringBeforeLast('.').lowercase() }.toSet()

        for (f in children) {
            val name = f.name ?: continue
            if (f.isDirectory) {
                walk(f, ancestors + name, out)
                continue
            }
            val ext = name.substringAfterLast('.', "").lowercase()
            val base = name.substringBeforeLast('.')
            // Track data files belong to their .cue sheet, so don't list them separately.
            if (ext in DISC_DATA && base.lowercase() in cueBases) continue
            // Arcade-style Neo Geo sets are plain zips, so allow them only through a folder hint.
            val system = Systems.detect(ext, ancestors) ?: continue
            out += Rom(f.uri.toString(), base, name, system.id)
        }
    }
}

object LibraryStore {
    private val json = Json { ignoreUnknownKeys = true }
    private fun file(ctx: Context) = File(ctx.filesDir, "library.json")

    fun load(ctx: Context): List<Rom> = runCatching {
        json.decodeFromString<List<Rom>>(file(ctx).readText())
    }.getOrDefault(emptyList())

    fun save(ctx: Context, roms: List<Rom>) {
        file(ctx).writeText(json.encodeToString(roms))
    }
}
