package com.retrohub.emulation

import android.net.Uri
import android.os.Bundle
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import com.retrohub.data.CoreManager
import com.retrohub.data.Systems
import com.retrohub.ui.RetroHubTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Hosts a LibretroDroid GLRetroView.
 *
 * NOTE: written against the LibretroDroid API as I remember it (GLRetroViewData fields,
 * sendKeyEvent / sendMotionEvent / serializeState / unserializeState). I could not fetch its
 * docs while building this, so if a name doesn't compile, check the current README.
 */
class GameActivity : ComponentActivity() {
    private var retroView: GLRetroView? = null
    private var stateFile: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        val system = Systems.byId(intent.getStringExtra(EXTRA_SYSTEM).orEmpty())
        val uri = intent.getStringExtra(EXTRA_URI)?.let(Uri::parse)
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        if (system == null || uri == null) {
            finish()
            return
        }
        stateFile = File(getExternalFilesDir("states"), "${system.id}_${title.replace(Regex("[^A-Za-z0-9._-]"), "_")}.state")

        setContent {
            RetroHubTheme {
                var view by remember { mutableStateOf<GLRetroView?>(null) }
                var status by remember { mutableStateOf("Preparing…") }
                var error by remember { mutableStateOf<String?>(null) }
                var showControls by remember { mutableStateOf(true) }

                LaunchedEffect(Unit) {
                    try {
                        val (coreFile, romFile) = withContext(Dispatchers.IO) {
                            val core = CoreManager.ensure(this@GameActivity, system.core) { status = it }
                            status = "Loading game…"
                            core to copyRomToCache(uri, title)
                        }
                        val data = GLRetroViewData(this@GameActivity).apply {
                            coreFilePath = coreFile.absolutePath
                            gameFilePath = romFile.absolutePath
                            systemDirectory = getExternalFilesDir("system")!!.absolutePath
                            savesDirectory = getExternalFilesDir("saves")!!.absolutePath
                        }
                        val v = GLRetroView(this@GameActivity, data)
                        lifecycle.addObserver(v)
                        retroView = v
                        view = v
                    } catch (e: Throwable) {
                        error = e.message ?: e.javaClass.simpleName
                    }
                }

                Box(Modifier.fillMaxSize().background(Color.Black)) {
                    val v = view
                    if (v != null) {
                        AndroidView(factory = { v }, modifier = Modifier.fillMaxSize())
                        if (showControls) TouchControls(onKey = { code, down -> sendKey(code, down) })
                        MenuButton(
                            onSave = ::saveState,
                            onLoad = ::loadState,
                            onToggleControls = { showControls = !showControls },
                            onQuit = { finish() },
                        )
                    } else {
                        Text(
                            error?.let { "Couldn't start: $it" } ?: status,
                            color = Color.White,
                            modifier = Modifier.align(Alignment.Center).padding(24.dp),
                        )
                    }
                }
            }
        }
    }

    /** SAF URIs can't be handed to a core as paths, so stage a copy in cache. */
    private fun copyRomToCache(uri: Uri, title: String): File {
        val ext = contentResolver.query(uri, arrayOf("_display_name"), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }?.substringAfterLast('.', "") ?: ""
        val dir = File(cacheDir, "roms").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() } // keep only the game being played
        val out = File(dir, if (ext.isNotEmpty()) "game.$ext" else "game")
        contentResolver.openInputStream(uri)!!.use { i -> out.outputStream().use { i.copyTo(it) } }
        return out
    }

    private fun sendKey(code: Int, down: Boolean) {
        retroView?.sendKeyEvent(if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, code, 0)
    }

    private fun saveState() {
        val v = retroView ?: return
        runCatching { stateFile?.writeBytes(v.serializeState()) }
            .onSuccess { toast("State saved") }
            .onFailure { toast("Save failed") }
    }

    private fun loadState() {
        val v = retroView ?: return
        val f = stateFile?.takeIf { it.exists() } ?: return toast("No saved state")
        runCatching { v.unserializeState(f.readBytes()) }
            .onSuccess { toast("State loaded") }
            .onFailure { toast("Load failed") }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---- physical gamepad support ----

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val fromPad = event.source and (InputDevice.SOURCE_GAMEPAD or InputDevice.SOURCE_DPAD) != 0
        if (fromPad && retroView != null && event.keyCode != KeyEvent.KEYCODE_BACK) {
            retroView?.sendKeyEvent(event.action, event.keyCode, 0)
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        val v = retroView
        if (v != null && event.source and InputDevice.SOURCE_JOYSTICK != 0 && event.action == MotionEvent.ACTION_MOVE) {
            v.sendMotionEvent(GLRetroView.MOTION_SOURCE_DPAD, event.getAxisValue(MotionEvent.AXIS_HAT_X), event.getAxisValue(MotionEvent.AXIS_HAT_Y), 0)
            v.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_LEFT, event.getAxisValue(MotionEvent.AXIS_X), event.getAxisValue(MotionEvent.AXIS_Y), 0)
            v.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_RIGHT, event.getAxisValue(MotionEvent.AXIS_Z), event.getAxisValue(MotionEvent.AXIS_RZ), 0)
            return true
        }
        return super.dispatchGenericMotionEvent(event)
    }

    companion object {
        const val EXTRA_URI = "uri"
        const val EXTRA_SYSTEM = "system"
        const val EXTRA_TITLE = "title"
    }
}

// ---------------------------------------------------------------- UI pieces

@Composable
private fun MenuButton(onSave: () -> Unit, onLoad: () -> Unit, onToggleControls: () -> Unit, onQuit: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().statusBarsPadding().padding(8.dp), contentAlignment = Alignment.TopEnd) {
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(Color(0x66000000))
                .pointerInput(Unit) { detectTapGestures { open = true } },
            contentAlignment = Alignment.Center,
        ) { Text("☰", color = Color.White) }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(text = { Text("Save state") }, onClick = { open = false; onSave() })
            DropdownMenuItem(text = { Text("Load state") }, onClick = { open = false; onLoad() })
            DropdownMenuItem(text = { Text("Show / hide controls") }, onClick = { open = false; onToggleControls() })
            DropdownMenuItem(text = { Text("Quit game") }, onClick = { open = false; onQuit() })
        }
    }
}

@Composable
private fun PadButton(label: String, code: Int, onKey: (Int, Boolean) -> Unit, size: Int = 52, round: Boolean = true) {
    Box(
        Modifier.size(size.dp)
            .clip(if (round) CircleShape else RoundedCornerShape(10.dp))
            .background(Color(0x55FFFFFF))
            .pointerInput(code) {
                detectTapGestures(onPress = {
                    onKey(code, true)
                    tryAwaitRelease()
                    onKey(code, false)
                })
            },
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Color.White) }
}

@Composable
private fun TouchControls(onKey: (Int, Boolean) -> Unit) {
    Column(
        Modifier.fillMaxSize().navigationBarsPadding().padding(12.dp),
        verticalArrangement = Arrangement.Bottom,
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PadButton("L", KeyEvent.KEYCODE_BUTTON_L1, onKey, 56, false)
                PadButton("L2", KeyEvent.KEYCODE_BUTTON_L2, onKey, 44, false)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PadButton("R2", KeyEvent.KEYCODE_BUTTON_R2, onKey, 44, false)
                PadButton("R", KeyEvent.KEYCODE_BUTTON_R1, onKey, 56, false)
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // D-pad
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                PadButton("▲", KeyEvent.KEYCODE_DPAD_UP, onKey, 48, false)
                Row(horizontalArrangement = Arrangement.spacedBy(48.dp)) {
                    PadButton("◀", KeyEvent.KEYCODE_DPAD_LEFT, onKey, 48, false)
                    PadButton("▶", KeyEvent.KEYCODE_DPAD_RIGHT, onKey, 48, false)
                }
                PadButton("▼", KeyEvent.KEYCODE_DPAD_DOWN, onKey, 48, false)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                PadButton("Select", KeyEvent.KEYCODE_BUTTON_SELECT, onKey, 56, false)
                PadButton("Start", KeyEvent.KEYCODE_BUTTON_START, onKey, 56, false)
            }
            // Face buttons (diamond)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                PadButton("X", KeyEvent.KEYCODE_BUTTON_X, onKey)
                Row(horizontalArrangement = Arrangement.spacedBy(44.dp)) {
                    PadButton("Y", KeyEvent.KEYCODE_BUTTON_Y, onKey)
                    PadButton("A", KeyEvent.KEYCODE_BUTTON_A, onKey)
                }
                PadButton("B", KeyEvent.KEYCODE_BUTTON_B, onKey)
            }
        }
    }
}
