package com.retrohub.data

enum class Kind { CONSOLE, HANDHELD }

/**
 * @param core       libretro core name, without the _libretro_android.so suffix
 * @param thumbDir   folder name on thumbnails.libretro.com
 * @param exts       file extensions this system accepts (lowercase)
 * @param aliases    folder names (letters/digits only, lowercase) that identify this system
 * @param gen        hardware generation (consoles: up to 6, handhelds: up to 8)
 * @param experimental core is heavy and/or may not exist as an Android build
 */
data class GameSystem(
    val id: String,
    val name: String,
    val kind: Kind,
    val gen: Int,
    val core: String,
    val thumbDir: String,
    val exts: Set<String>,
    val aliases: Set<String>,
    val experimental: Boolean = false,
)

object Systems {
    private val ARCHIVES = setOf("zip", "7z")

    private fun s(
        id: String, name: String, kind: Kind, gen: Int, core: String, thumbDir: String,
        exts: String, aliases: String, experimental: Boolean = false,
    ) = GameSystem(
        id, name, kind, gen, core, thumbDir,
        exts.split(",").map { it.trim() }.toSet() + ARCHIVES,
        (aliases.split(",").map { it.trim() } + id).toSet(),
        experimental,
    )

    val all: List<GameSystem> = listOf(
        // ---------------- Consoles, gen 1-6 ----------------
        s("vectrex", "Vectrex", Kind.CONSOLE, 2, "vecx", "GCE - Vectrex", "vec,bin", "vectrex"),
        s("odyssey2", "Odyssey 2", Kind.CONSOLE, 2, "o2em", "Magnavox - Odyssey2", "bin", "odyssey2,videopac"),
        s("colecovision", "ColecoVision", Kind.CONSOLE, 2, "gearcoleco", "Coleco - ColecoVision", "col,bin,rom", "coleco,colecovision"),
        s("intellivision", "Intellivision", Kind.CONSOLE, 2, "freeintv", "Mattel - Intellivision", "int,bin,rom", "intellivision"),
        s("atari2600", "Atari 2600", Kind.CONSOLE, 2, "stella", "Atari - 2600", "a26,bin", "atari2600,a2600,2600"),
        s("atari5200", "Atari 5200", Kind.CONSOLE, 2, "a5200", "Atari - 5200", "a52,bin,rom", "atari5200,a5200,5200"),
        s("atari7800", "Atari 7800", Kind.CONSOLE, 3, "prosystem", "Atari - 7800", "a78,bin", "atari7800,a7800,7800"),
        s("sg1000", "SG-1000", Kind.CONSOLE, 3, "genesis_plus_gx", "Sega - SG-1000", "sg", "sg1000"),
        s("nes", "NES / Famicom", Kind.CONSOLE, 3, "fceumm", "Nintendo - Nintendo Entertainment System", "nes,fds,unf", "nes,famicom,nintendo"),
        s("sms", "Master System", Kind.CONSOLE, 3, "genesis_plus_gx", "Sega - Master System - Mark III", "sms", "mastersystem,sms,markiii"),
        s("pce", "PC Engine / TurboGrafx-16", Kind.CONSOLE, 4, "mednafen_pce_fast", "NEC - PC Engine - TurboGrafx 16", "pce,sgx", "pcengine,turbografx16,tg16,pce"),
        s("pcecd", "PC Engine CD", Kind.CONSOLE, 4, "mednafen_pce_fast", "NEC - PC Engine CD - TurboGrafx-CD", "cue,chd,ccd", "pcenginecd,turbografxcd,tgcd,pcecd"),
        s("genesis", "Genesis / Mega Drive", Kind.CONSOLE, 4, "genesis_plus_gx", "Sega - Mega Drive - Genesis", "md,gen,smd,bin", "genesis,megadrive,md,segagenesis"),
        s("segacd", "Sega CD / Mega-CD", Kind.CONSOLE, 4, "genesis_plus_gx", "Sega - Mega-CD - Sega CD", "cue,chd,iso", "segacd,megacd"),
        s("neogeo", "Neo Geo (AES/MVS)", Kind.CONSOLE, 4, "fbneo", "SNK - Neo Geo", "", "neogeo,neogeoaes,neogeomvs"),
        s("snes", "SNES / Super Famicom", Kind.CONSOLE, 4, "snes9x", "Nintendo - Super Nintendo Entertainment System", "sfc,smc,swc,fig", "snes,superfamicom,supernintendo"),
        s("sega32x", "Sega 32X", Kind.CONSOLE, 5, "picodrive", "Sega - 32X", "32x", "sega32x,32x"),
        s("3do", "3DO", Kind.CONSOLE, 5, "opera", "The 3DO Company - 3DO", "iso,cue,chd", "3do"),
        s("jaguar", "Atari Jaguar", Kind.CONSOLE, 5, "virtualjaguar", "Atari - Jaguar", "j64,jag", "jaguar,atarijaguar"),
        s("psx", "PlayStation", Kind.CONSOLE, 5, "pcsx_rearmed", "Sony - PlayStation", "cue,chd,pbp,m3u,iso,img,bin", "psx,ps1,playstation,psone"),
        s("saturn", "Saturn", Kind.CONSOLE, 5, "yabasanshiro", "Sega - Saturn", "cue,chd,iso,mdf", "saturn,segasaturn", experimental = true),
        s("n64", "Nintendo 64", Kind.CONSOLE, 5, "mupen64plus_next_gles3", "Nintendo - Nintendo 64", "n64,z64,v64", "n64,nintendo64"),
        s("dreamcast", "Dreamcast", Kind.CONSOLE, 6, "flycast", "Sega - Dreamcast", "cdi,gdi,chd,cue", "dreamcast,dc"),
        s("gc", "GameCube", Kind.CONSOLE, 6, "dolphin", "Nintendo - GameCube", "gcm,gcz,rvz,iso,ciso", "gamecube,gc,ngc", experimental = true),
        s("ps2", "PlayStation 2", Kind.CONSOLE, 6, "pcsx2", "Sony - PlayStation 2", "iso,chd,cso", "ps2,playstation2", experimental = true),

        // ---------------- Handhelds, gen 1-8 ----------------
        s("gb", "Game Boy", Kind.HANDHELD, 4, "gambatte", "Nintendo - Game Boy", "gb", "gb,gameboy"),
        s("gg", "Game Gear", Kind.HANDHELD, 4, "genesis_plus_gx", "Sega - Game Gear", "gg", "gamegear,gg"),
        s("lynx", "Atari Lynx", Kind.HANDHELD, 4, "handy", "Atari - Lynx", "lnx,lyx", "lynx,atarilynx"),
        s("gbc", "Game Boy Color", Kind.HANDHELD, 5, "gambatte", "Nintendo - Game Boy Color", "gbc", "gbc,gameboycolor"),
        s("ngp", "Neo Geo Pocket", Kind.HANDHELD, 5, "mednafen_ngp", "SNK - Neo Geo Pocket", "ngp", "neogeopocket,ngp"),
        s("ngpc", "Neo Geo Pocket Color", Kind.HANDHELD, 5, "mednafen_ngp", "SNK - Neo Geo Pocket Color", "ngc", "neogeopocketcolor,ngpc"),
        s("ws", "WonderSwan", Kind.HANDHELD, 5, "mednafen_wswan", "Bandai - WonderSwan", "ws", "wonderswan,ws"),
        s("wsc", "WonderSwan Color", Kind.HANDHELD, 5, "mednafen_wswan", "Bandai - WonderSwan Color", "wsc", "wonderswancolor,wsc"),
        s("vb", "Virtual Boy", Kind.HANDHELD, 5, "mednafen_vb", "Nintendo - Virtual Boy", "vb,vboy", "virtualboy,vb"),
        s("pokemini", "Pokemon Mini", Kind.HANDHELD, 5, "pokemini", "Nintendo - Pokemon Mini", "min", "pokemonmini,pokemini"),
        s("gba", "Game Boy Advance", Kind.HANDHELD, 6, "mgba", "Nintendo - Game Boy Advance", "gba", "gba,gameboyadvance"),
        s("nds", "Nintendo DS", Kind.HANDHELD, 7, "melonds", "Nintendo - Nintendo DS", "nds,dsi", "nds,ds,nintendods"),
        s("psp", "PlayStation Portable", Kind.HANDHELD, 7, "ppsspp", "Sony - PlayStation Portable", "iso,cso,pbp,chd", "psp,playstationportable"),
        s("3ds", "Nintendo 3DS", Kind.HANDHELD, 8, "citra", "Nintendo - Nintendo 3DS", "3ds,cci,cxi,cia", "3ds,nintendo3ds", experimental = true),
        // PS Vita (gen 8) has no libretro core, so it is intentionally absent.
    )

    private val byId = all.associateBy { it.id }
    fun byId(id: String): GameSystem? = byId[id]

    private val byExt: Map<String, List<GameSystem>> =
        all.flatMap { sys -> sys.exts.map { it to sys } }.groupBy({ it.first }, { it.second })

    private fun normalize(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    /**
     * Decide which system a file belongs to.
     * 1. Nearest ancestor folder whose name matches a system alias and that system accepts the extension.
     * 2. Otherwise the extension must belong to exactly one system.
     * Ambiguous formats (bin, iso, cue, chd, zip...) therefore need a per-system folder.
     */
    fun detect(ext: String, ancestors: List<String>): GameSystem? {
        for (folder in ancestors.asReversed()) {
            val n = normalize(folder)
            val hit = all.firstOrNull { n in it.aliases && ext in it.exts }
            if (hit != null) return hit
        }
        return byExt[ext]?.singleOrNull()
    }
}
