package com.retrohub.data

import android.content.Context
import android.net.Uri
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Box art comes from the libretro-thumbnails project:
 *   https://thumbnails.libretro.com/<System folder>/Named_Boxarts/<Game name>.png
 * Names must match the No-Intro / Redump style title ("Super Mario World (USA)").
 */
object ArtScraper {
    private const val BASE = "https://thumbnails.libretro.com"
    private val ILLEGAL = Regex("[&*/:`<>?\\\\|]")
    private val REGION_GUESSES = listOf(" (USA)", " (Europe)", " (World)", " (Japan)", " (Japan, USA)", " (USA, Europe)")

    /** libretro-thumbnails replaces these characters with '_' in file names. */
    fun sanitize(name: String) = name.replace(ILLEGAL, "_")

    fun artFile(ctx: Context, rom: Rom) =
        File(ctx.filesDir, "art/${rom.systemId}/${sanitize(rom.title)}.png")

    private fun candidates(title: String): List<String> {
        val t = title.trim()
        val firstTag = Regex("^(.*?\\([^)]*\\))").find(t)?.value
        val noTags = t.substringBefore(" (").trim()
        return buildList {
            add(t)
            if (firstTag != null) add(firstTag)
            REGION_GUESSES.forEach { add(noTags + it) }
        }.distinct()
    }

    /** Returns true if art exists locally after the call. Blocking; call from IO. */
    fun fetch(ctx: Context, rom: Rom): Boolean {
        val out = artFile(ctx, rom)
        if (out.exists()) return true
        val system = Systems.byId(rom.systemId) ?: return false
        out.parentFile?.mkdirs()

        for (name in candidates(rom.title)) {
            val url = "$BASE/${Uri.encode(system.thumbDir)}/Named_Boxarts/${Uri.encode(sanitize(name))}.png"
            val conn = runCatching { URL(url).openConnection() as HttpURLConnection }.getOrNull() ?: continue
            try {
                conn.connectTimeout = 8_000
                conn.readTimeout = 15_000
                if (conn.responseCode == 200) {
                    val tmp = File(out.path + ".tmp")
                    conn.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
                    tmp.renameTo(out)
                    return true
                }
            } catch (_: Exception) {
                // network hiccup or 404: try the next candidate
            } finally {
                conn.disconnect()
            }
        }
        return false
    }
}
