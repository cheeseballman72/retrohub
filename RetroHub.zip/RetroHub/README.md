# RetroHub

A Lemuroid-style Android frontend built on libretro cores (via LibretroDroid).

- **Systems:** consoles up to 6th gen (Atari 2600 → Dreamcast, plus experimental GameCube / PS2) and handhelds up to 8th gen (Game Boy → 3DS, experimental). PS Vita has no libretro core, so it isn't included. See `data/Systems.kt`.
- **Cores:** downloaded on first launch from the libretro nightly Android buildbot, or sideloaded into `Android/data/com.retrohub/files/cores/`.
- **Box art:** scraped from thumbnails.libretro.com (`Named_Boxarts`) after each scan, or on demand from Settings.
- **Apps tab:** lists every launchable app on the phone and starts it. RetroHub also declares itself a HOME app, so you can set it as your launcher.
- **Input:** on-screen controls plus physical gamepads. Save/load state from the in-game menu.

## Build
Open in Android Studio (Ladybug or newer) and run. No Gradle wrapper jar is included: let Android Studio generate it, or run `gradle wrapper`.

## Things to check first (I could not compile or run this)
1. **LibretroDroid version** in `app/build.gradle.kts` (`libretroDroidVersion`) is a guess. Check the project's releases and update it. The game screen was written from memory of its API (`GLRetroViewData`, `sendKeyEvent`, `sendMotionEvent`, `serializeState`), so a name may need adjusting.
2. **Core names / availability.** Experimental systems (GameCube, PS2, Saturn, 3DS) may not have an Android build. The app shows an error if the download 404s. Heavy cores need a fast phone.
3. **Thumbnail folder names** in `Systems.kt` follow the libretro-thumbnails naming as I know it; a wrong one just means no art for that system.

## Using it
1. Settings → Choose ROM folder. Use one sub-folder per system (`SNES`, `PSX`, `Dreamcast`…); required for disc formats (cue/chd/iso/bin) and zips.
2. Put BIOS files in the folder shown in Settings (`…/files/system`).
3. Art matches by file name, so No-Intro style names (`Super Mario World (USA).sfc`) get the best hit rate.

## Notes
- ROMs are copied to cache before launch because cores need real file paths; large disc images take a moment.
- Cores are downloaded executable code, so this is meant for sideloading, not Google Play.
- You supply your own legally obtained ROMs and BIOS files.

## Building without Android Studio
**GitHub Actions (no local install):** push this folder to a new GitHub repo (the web "Upload files" button works from a phone). The `Build APK` workflow runs on every push; when it finishes, open the run and download the `RetroHub-debug-apk` artifact, then sideload the APK. If the build fails, the log shows the compile errors.

**Command line:** install JDK 17, the Android command-line tools (`sdkmanager "platforms;android-35" "build-tools;35.0.0"`) and Gradle 8.9, set `ANDROID_HOME`, then run `gradle :app:assembleDebug`. The APK lands in `app/build/outputs/apk/debug/`.
